--
-- PostgreSQL database dump
--

\restrict FKkPWghiN0mt3FMrr4TbcsLtOrV0E6gVClL6mLzLU3ypkOW6DCS7EjThvAeAr4M

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

-- Started on 2025-09-19 22:21:26

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 857 (class 1247 OID 17092)
-- Name: problem_priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.problem_priority AS ENUM (
    'low',
    'medium',
    'high'
);


ALTER TYPE public.problem_priority OWNER TO postgres;

--
-- TOC entry 860 (class 1247 OID 17100)
-- Name: problem_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.problem_status AS ENUM (
    'pending',
    'in-progress',
    'resolved',
    'closed'
);


ALTER TYPE public.problem_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 17110)
-- Name: administrators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.administrators (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(100) DEFAULT 'City Administrator'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone
);


ALTER TABLE public.administrators OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 17109)
-- Name: administrators_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.administrators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.administrators_id_seq OWNER TO postgres;

--
-- TOC entry 4982 (class 0 OID 0)
-- Dependencies: 217
-- Name: administrators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.administrators_id_seq OWNED BY public.administrators.id;


--
-- TOC entry 226 (class 1259 OID 17170)
-- Name: assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assignments (
    id integer NOT NULL,
    problem_id integer,
    worker_id integer,
    assigned_by integer,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone,
    notes text
);


ALTER TABLE public.assignments OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 17169)
-- Name: assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.assignments_id_seq OWNER TO postgres;

--
-- TOC entry 4983 (class 0 OID 0)
-- Dependencies: 225
-- Name: assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.assignments_id_seq OWNED BY public.assignments.id;


--
-- TOC entry 228 (class 1259 OID 17195)
-- Name: problem_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.problem_history (
    id integer NOT NULL,
    problem_id integer,
    status public.problem_status,
    changed_by integer,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


ALTER TABLE public.problem_history OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 17194)
-- Name: problem_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.problem_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.problem_history_id_seq OWNER TO postgres;

--
-- TOC entry 4984 (class 0 OID 0)
-- Dependencies: 227
-- Name: problem_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.problem_history_id_seq OWNED BY public.problem_history.id;


--
-- TOC entry 224 (class 1259 OID 17150)
-- Name: problems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.problems (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    ward_id integer,
    location text NOT NULL,
    priority public.problem_priority DEFAULT 'medium'::public.problem_priority,
    status public.problem_status DEFAULT 'pending'::public.problem_status,
    ml_score numeric(3,2) DEFAULT 0.5,
    reported_by character varying(255) NOT NULL,
    reported_on date DEFAULT CURRENT_DATE,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.problems OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 17149)
-- Name: problems_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.problems_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.problems_id_seq OWNER TO postgres;

--
-- TOC entry 4985 (class 0 OID 0)
-- Dependencies: 223
-- Name: problems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.problems_id_seq OWNED BY public.problems.id;


--
-- TOC entry 220 (class 1259 OID 17123)
-- Name: wards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wards (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    boundaries text
);


ALTER TABLE public.wards OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 17122)
-- Name: wards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wards_id_seq OWNER TO postgres;

--
-- TOC entry 4986 (class 0 OID 0)
-- Dependencies: 219
-- Name: wards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wards_id_seq OWNED BY public.wards.id;


--
-- TOC entry 222 (class 1259 OID 17132)
-- Name: workers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(20),
    specialization character varying(255),
    ward_id integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workers OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 17131)
-- Name: workers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workers_id_seq OWNER TO postgres;

--
-- TOC entry 4987 (class 0 OID 0)
-- Dependencies: 221
-- Name: workers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workers_id_seq OWNED BY public.workers.id;


--
-- TOC entry 4773 (class 2604 OID 17113)
-- Name: administrators id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrators ALTER COLUMN id SET DEFAULT nextval('public.administrators_id_seq'::regclass);


--
-- TOC entry 4787 (class 2604 OID 17173)
-- Name: assignments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments ALTER COLUMN id SET DEFAULT nextval('public.assignments_id_seq'::regclass);


--
-- TOC entry 4789 (class 2604 OID 17198)
-- Name: problem_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problem_history ALTER COLUMN id SET DEFAULT nextval('public.problem_history_id_seq'::regclass);


--
-- TOC entry 4780 (class 2604 OID 17153)
-- Name: problems id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problems ALTER COLUMN id SET DEFAULT nextval('public.problems_id_seq'::regclass);


--
-- TOC entry 4776 (class 2604 OID 17126)
-- Name: wards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards ALTER COLUMN id SET DEFAULT nextval('public.wards_id_seq'::regclass);


--
-- TOC entry 4777 (class 2604 OID 17135)
-- Name: workers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workers ALTER COLUMN id SET DEFAULT nextval('public.workers_id_seq'::regclass);


--
-- TOC entry 4966 (class 0 OID 17110)
-- Dependencies: 218
-- Data for Name: administrators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.administrators (id, email, password_hash, name, role, created_at, last_login) FROM stdin;
1	admin@city.gov	$2a$10$r8va3nDCI2h6p6cC58Ay.eVXoYw6haEwjJNlJtRk6Jq6kZ5Q6b6Xe	City Administrator	City Administrator	2025-09-19 20:55:51.501296	\N
\.


--
-- TOC entry 4974 (class 0 OID 17170)
-- Dependencies: 226
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assignments (id, problem_id, worker_id, assigned_by, assigned_at, completed_at, notes) FROM stdin;
1	3	4	1	2025-09-19 20:56:06.398821	\N	\N
\.


--
-- TOC entry 4976 (class 0 OID 17195)
-- Dependencies: 228
-- Data for Name: problem_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.problem_history (id, problem_id, status, changed_by, changed_at, notes) FROM stdin;
\.


--
-- TOC entry 4972 (class 0 OID 17150)
-- Dependencies: 224
-- Data for Name: problems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.problems (id, title, description, ward_id, location, priority, status, ml_score, reported_by, reported_on, created_at, updated_at) FROM stdin;
1	Pothole on Main Street	Large pothole causing traffic issues and potential damage to vehicles	1	Main Street & 5th Avenue	high	pending	0.92	John Smith	2023-10-15	2025-09-19 20:56:00.104762	2025-09-19 20:56:00.104762
2	Garbage Overflow	Garbage bin overflowing near park entrance	2	Central Park West	medium	pending	0.76	Emma Johnson	2023-10-14	2025-09-19 20:56:00.104762	2025-09-19 20:56:00.104762
3	Street Light Not Working	Light pole not functioning after dark	3	Oak Street	high	pending	0.88	Michael Chen	2023-10-13	2025-09-19 20:56:00.104762	2025-09-19 20:56:00.104762
4	Water Leakage	Water leaking from main pipeline	1	Elm Street	high	pending	0.95	Sarah Williams	2023-10-15	2025-09-19 20:56:00.104762	2025-09-19 20:56:00.104762
\.


--
-- TOC entry 4968 (class 0 OID 17123)
-- Dependencies: 220
-- Data for Name: wards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wards (id, name, description, boundaries) FROM stdin;
1	Ward 1	Downtown area with commercial and residential buildings	\N
2	Ward 2	Suburban residential area with parks	\N
3	Ward 3	Industrial and commercial zone	\N
4	Ward 4	Mixed residential and commercial area	\N
\.


--
-- TOC entry 4970 (class 0 OID 17132)
-- Dependencies: 222
-- Data for Name: workers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workers (id, name, email, phone, specialization, ward_id, is_active, created_at) FROM stdin;
1	Public Works Team A	team-a@city.gov	555-1234	Infrastructure repairs	1	t	2025-09-19 20:55:56.108802
2	Public Works Team B	team-b@city.gov	555-5678	Infrastructure maintenance	2	t	2025-09-19 20:55:56.108802
3	Sanitation Department	sanitation@city.gov	555-9012	Waste management	3	t	2025-09-19 20:55:56.108802
4	Electrical Team	electrical@city.gov	555-3456	Street lights and electrical issues	4	t	2025-09-19 20:55:56.108802
5	Water Department	water@city.gov	555-7890	Water and pipeline issues	1	t	2025-09-19 20:55:56.108802
\.


--
-- TOC entry 4988 (class 0 OID 0)
-- Dependencies: 217
-- Name: administrators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.administrators_id_seq', 1, true);


--
-- TOC entry 4989 (class 0 OID 0)
-- Dependencies: 225
-- Name: assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assignments_id_seq', 1, true);


--
-- TOC entry 4990 (class 0 OID 0)
-- Dependencies: 227
-- Name: problem_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.problem_history_id_seq', 1, false);


--
-- TOC entry 4991 (class 0 OID 0)
-- Dependencies: 223
-- Name: problems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.problems_id_seq', 4, true);


--
-- TOC entry 4992 (class 0 OID 0)
-- Dependencies: 219
-- Name: wards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wards_id_seq', 4, true);


--
-- TOC entry 4993 (class 0 OID 0)
-- Dependencies: 221
-- Name: workers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workers_id_seq', 5, true);


--
-- TOC entry 4792 (class 2606 OID 17121)
-- Name: administrators administrators_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrators
    ADD CONSTRAINT administrators_email_key UNIQUE (email);


--
-- TOC entry 4794 (class 2606 OID 17119)
-- Name: administrators administrators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrators
    ADD CONSTRAINT administrators_pkey PRIMARY KEY (id);


--
-- TOC entry 4808 (class 2606 OID 17178)
-- Name: assignments assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4812 (class 2606 OID 17203)
-- Name: problem_history problem_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problem_history
    ADD CONSTRAINT problem_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4806 (class 2606 OID 17163)
-- Name: problems problems_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problems
    ADD CONSTRAINT problems_pkey PRIMARY KEY (id);


--
-- TOC entry 4796 (class 2606 OID 17130)
-- Name: wards wards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wards
    ADD CONSTRAINT wards_pkey PRIMARY KEY (id);


--
-- TOC entry 4798 (class 2606 OID 17143)
-- Name: workers workers_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_email_key UNIQUE (email);


--
-- TOC entry 4800 (class 2606 OID 17141)
-- Name: workers workers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_pkey PRIMARY KEY (id);


--
-- TOC entry 4809 (class 1259 OID 17218)
-- Name: idx_assignments_problem_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_problem_id ON public.assignments USING btree (problem_id);


--
-- TOC entry 4810 (class 1259 OID 17219)
-- Name: idx_assignments_worker_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_worker_id ON public.assignments USING btree (worker_id);


--
-- TOC entry 4801 (class 1259 OID 17217)
-- Name: idx_problems_ml_score; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_problems_ml_score ON public.problems USING btree (ml_score);


--
-- TOC entry 4802 (class 1259 OID 17216)
-- Name: idx_problems_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_problems_priority ON public.problems USING btree (priority);


--
-- TOC entry 4803 (class 1259 OID 17215)
-- Name: idx_problems_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_problems_status ON public.problems USING btree (status);


--
-- TOC entry 4804 (class 1259 OID 17214)
-- Name: idx_problems_ward_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_problems_ward_id ON public.problems USING btree (ward_id);


--
-- TOC entry 4815 (class 2606 OID 17189)
-- Name: assignments assignments_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.administrators(id);


--
-- TOC entry 4816 (class 2606 OID 17179)
-- Name: assignments assignments_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES public.problems(id) ON DELETE CASCADE;


--
-- TOC entry 4817 (class 2606 OID 17184)
-- Name: assignments assignments_worker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_worker_id_fkey FOREIGN KEY (worker_id) REFERENCES public.workers(id);


--
-- TOC entry 4818 (class 2606 OID 17209)
-- Name: problem_history problem_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problem_history
    ADD CONSTRAINT problem_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.administrators(id);


--
-- TOC entry 4819 (class 2606 OID 17204)
-- Name: problem_history problem_history_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problem_history
    ADD CONSTRAINT problem_history_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES public.problems(id) ON DELETE CASCADE;


--
-- TOC entry 4814 (class 2606 OID 17164)
-- Name: problems problems_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problems
    ADD CONSTRAINT problems_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id);


--
-- TOC entry 4813 (class 2606 OID 17144)
-- Name: workers workers_ward_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workers
    ADD CONSTRAINT workers_ward_id_fkey FOREIGN KEY (ward_id) REFERENCES public.wards(id);


-- Completed on 2025-09-19 22:21:27

--
-- PostgreSQL database dump complete
--

\unrestrict FKkPWghiN0mt3FMrr4TbcsLtOrV0E6gVClL6mLzLU3ypkOW6DCS7EjThvAeAr4M

