import React, { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const [workers, setWorkers] = useState([]);
  const [selectedWorker, setSelectedWorker] = useState({});
  const [filterWard, setFilterWard] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");

    // Fetch complaints
    axios.get("http://localhost:3000/complaints", {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => setComplaints(res.data))
    .catch(err => console.error(err));

    // Fetch workers
    axios.get("http://localhost:3000/workers", {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => setWorkers(res.data))
    .catch(err => console.error(err));
  }, []);

  const handleAssign = async (complaintId, workerId, userId) => {
    const token = localStorage.getItem("token");
    try {
      await axios.post("http://localhost:3000/assign", {
        complaintId, workerId
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      await axios.post("http://localhost:3000/notify", {
        userId,
        message: "Your problem has been assigned to a worker."
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      alert("Job assigned and user notified!");
    } catch (err) {
      console.error(err);
      alert("Error assigning job");
    }
  };

  const sortedComplaints = [...complaints]
    .filter(c => filterWard ? c.ward === filterWard : true)
    .sort((a, b) => b.priority_score - a.priority_score);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Admin Dashboard</h1>
      <p>Welcome to the dashboard!</p>

      {/* Filter by ward */}
      <div>
        <label>Filter by Ward: </label>
        <input
          type="text"
          value={filterWard}
          onChange={(e) => setFilterWard(e.target.value)}
          placeholder="Enter Ward ID/Name"
        />
      </div>

      <h3>Complaints (Prioritized)</h3>
      <table border="1" cellPadding="8" style={{ marginTop: "10px", width: "100%" }}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Description</th>
            <th>Ward</th>
            <th>Priority Score</th>
            <th>Assign To</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {sortedComplaints.map(c => (
            <tr key={c.id}>
              <td>{c.id}</td>
              <td>{c.description}</td>
              <td>{c.ward}</td>
              <td>{c.priority_score}</td>
              <td>
                <select
                  onChange={(e) => setSelectedWorker({ ...selectedWorker, [c.id]: e.target.value })}
                >
                  <option>Select Worker</option>
                  {workers.map(w => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.role})
                    </option>
                  ))}
                </select>
              </td>
              <td>
                <button
                  onClick={() => handleAssign(c.id, selectedWorker[c.id], c.user_id)}
                  disabled={!selectedWorker[c.id]}
                >
                  Assign
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Workers</h3>
      <ul>
        {workers.map(w => (
          <li key={w.id}>{w.name} - {w.role} (Ward: {w.ward})</li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
