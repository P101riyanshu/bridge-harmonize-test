import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AdminLogin from "./AdminLogin";
import Dashboard from "./Dashboard";
import Problems from "./Problems";
import Workers from "./Workers";
import Analytics from "./Analytics";
import Settings from "./Settings";

function App() {
  return (
    <Router>
      <Routes>
        {/* Login Routes */}
        <Route path="/" element={<AdminLogin />} />
        <Route path="/admin/login" element={<AdminLogin />} />

        {/* Dashboard + Sidebar Routes */}
        <Route path="/admin/dashboard" element={<Dashboard />} />
        <Route path="/admin/problems" element={<Problems />} />
        <Route path="/admin/workers" element={<Workers />} />
        <Route path="/admin/analytics" element={<Analytics />} />
        <Route path="/admin/settings" element={<Settings />} />
      </Routes>
    </Router>
  );
}

export default App;
