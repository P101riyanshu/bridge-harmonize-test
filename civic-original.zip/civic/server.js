const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const logger = require('./utils/logger');

// Load environment variables FIRST
dotenv.config();

// Route files
const authRoutes = require('./routes/auth');
const reportRoutes = require('./routes/reports');
const mapRoutes = require('./routes/map');
const adminRoutes = require('./routes/admin');

// Initialize express
const app = express();

// Security middleware
app.use(helmet());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.NODE_ENV === 'development' ? 1000 : 100, // More generous in development
  message: JSON.stringify({
    success: false,
    message: 'Too many requests, please try again later.'
  })
});
app.use(limiter);

// Body parser middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Enable CORS
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Handle pre-flight requests for all routes
app.options('*', cors());

// Mount routers
app.use('/api/auth', authRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/map', mapRoutes);
app.use('/api/admin', adminRoutes);

// Test database connection endpoint
app.get('/api/test-db', async (req, res) => {
  try {
    const pool = require('./config/database');
    const [result] = await pool.execute('SELECT 1 + 1 AS solution');
    res.json({ 
      success: true, 
      message: 'Database connection successful',
      data: result[0] 
    });
  } catch (error) {
    logger.error('Database test failed:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Database connection failed: ' + error.message 
    });
  }
});

// Basic root route for health checks
app.get('/', (req, res) => {
  res.json({ 
    success: true,
    message: 'Civic Issue Reporting API is running!',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Debug endpoint to show all registered routes
app.get('/api/debug/routes', (req, res) => {
  const routes = [];
  
  app._router.stack.forEach(middleware => {
    if (middleware.route) {
      // Routes registered directly on app
      routes.push({
        path: middleware.route.path,
        methods: Object.keys(middleware.route.methods)
      });
    } else if (middleware.name === 'router') {
      // Router middleware - this is where our API routes are
      middleware.handle.stack.forEach(handler => {
        if (handler.route) {
          const routePath = middleware.regexp.toString()
            .replace(/^\/\^\\\//, '')
            .replace(/\\\/\?\(\?=\/\|\$\)\/\i$/, '')
            .replace(/\\\//g, '/')
            .replace(/\^|\$|\\/g, '');
          
          routes.push({
            path: '/' + routePath + handler.route.path,
            methods: Object.keys(handler.route.methods)
          });
        }
      });
    }
  });
  
  res.json({ success: true, routes });
});

// Handle undefined routes
app.use('*', (req, res) => {
  res.status(404).json({ 
    success: false,
    message: 'Route not found',
    requestedUrl: req.originalUrl
  });
});

// Global error handling middleware
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({ 
    success: false,
    message: 'Something went wrong!',
    ...(process.env.NODE_ENV === 'development' && { error: err.message })
  });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
  logger.info(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
});

module.exports = app;