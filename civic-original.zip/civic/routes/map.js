const express = require('express');
const pool = require('../config/database');
const { protect } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();

// Get map clusters for visualizing reports
router.get('/clusters', async (req, res) => {
  const { zoom, bounds } = req.query;
  
  try {
    console.log('📊 Map clusters request:', { zoom, bounds });
    
    // Default simple query that works even with empty database
    let query = `
      SELECT 
        FLOOR(COALESCE(latitude, 0) * 100) / 100 as clusterLat,
        FLOOR(COALESCE(longitude, 0) * 100) / 100 as clusterLng,
        COUNT(*) as pointCount,
        COALESCE(category, 'unknown') as category,
        COALESCE(status, 'submitted') as status
      FROM reports 
    `;
    
    let queryParams = [];
    
    // If bounds are provided, filter by map viewport
    if (bounds) {
      try {
        const [swLng, swLat, neLng, neLat] = bounds.split(',').map(parseFloat);
        query += ' WHERE latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?';
        queryParams = [swLat, neLat, swLng, neLng];
      } catch (error) {
        console.warn('Invalid bounds parameter:', bounds);
        // Continue without bounds filter
      }
    }
    
    query += ' GROUP BY clusterLat, clusterLng, category ORDER BY pointCount DESC';
    
    console.log('Executing clusters query:', query);
    console.log('Query parameters:', queryParams);
    
    const [clusters] = await pool.execute(query, queryParams);
    
    console.log(`Found ${clusters.length} clusters`);
    
    res.json({
      success: true,
      clusters: clusters.map(cluster => ({
        latitude: parseFloat(cluster.clusterLat) || 0,
        longitude: parseFloat(cluster.clusterLng) || 0,
        pointCount: cluster.pointCount || 0,
        category: cluster.category || 'unknown',
        status: cluster.status || 'submitted'
      }))
    });
    
  } catch (error) {
    console.error('❌ Map clusters error:');
    console.error('Error message:', error.message);
    console.error('Error code:', error.code);
    console.error('Error sqlMessage:', error.sqlMessage);
    
    logger.error('Map clusters error:', error);
    
    res.status(500).json({
      success: false,
      message: 'Error fetching map clusters',
      ...(process.env.NODE_ENV === 'development' && { error: error.message })
    });
  }
});

// Get reports within map bounds
router.get('/reports-in-bounds', async (req, res) => {
  const { bounds } = req.query;
  
  try {
    console.log('📊 Reports in bounds request:', { bounds });
    
    if (!bounds) {
      return res.status(400).json({
        success: false,
        message: 'Bounds parameter is required'
      });
    }
    
    let [swLng, swLat, neLng, neLat] = [0, 0, 0, 0];
    
    try {
      [swLng, swLat, neLng, neLat] = bounds.split(',').map(parseFloat);
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: 'Invalid bounds format. Use: swLng,swLat,neLng,neLat'
      });
    }
    
    const [reports] = await pool.execute(`
      SELECT 
        r.*, 
        u.name as user_name
      FROM reports r
      LEFT JOIN users u ON r.user_id = u.id
      WHERE latitude BETWEEN ? AND ? 
        AND longitude BETWEEN ? AND ?
      ORDER BY r.created_at DESC
      LIMIT 100
    `, [swLat, neLat, swLng, neLng]);
    
    console.log(`Found ${reports.length} reports in bounds`);
    
    res.json({
      success: true,
      reports
    });
    
  } catch (error) {
    console.error('Reports in bounds error:', error);
    logger.error('Reports in bounds error:', error);
    
    res.status(500).json({
      success: false,
      message: 'Error fetching reports in bounds',
      ...(process.env.NODE_ENV === 'development' && { error: error.message })
    });
  }
});

// Get heatmap data for reports
router.get('/heatmap', async (req, res) => {
  try {
    console.log('📊 Heatmap request received');
    
    // Simplified heatmap query that works with any database state
    const [heatmapData] = await pool.execute(`
      SELECT 
        ROUND(COALESCE(latitude, 0), 3) as latitude,
        ROUND(COALESCE(longitude, 0), 3) as longitude,
        COUNT(*) as intensity,
        COALESCE(category, 'unknown') as category
      FROM reports 
      GROUP BY ROUND(COALESCE(latitude, 0), 3), ROUND(COALESCE(longitude, 0), 3), category
      ORDER BY intensity DESC
      LIMIT 100
    `);
    
    console.log(`Generated heatmap with ${heatmapData.length} points`);
    
    res.json({
      success: true,
      heatmap: heatmapData.map(point => ({
        latitude: parseFloat(point.latitude) || 0,
        longitude: parseFloat(point.longitude) || 0,
        intensity: point.intensity || 0,
        category: point.category || 'unknown'
      }))
    });
    
  } catch (error) {
    console.error('Heatmap error:', error);
    logger.error('Heatmap error:', error);
    
    res.status(500).json({
      success: false,
      message: 'Error fetching heatmap data',
      ...(process.env.NODE_ENV === 'development' && { error: error.message })
    });
  }
});

// Get reports by category for statistics
router.get('/categories', async (req, res) => {
  try {
    console.log('📊 Categories request received');
    
    const [categoryData] = await pool.execute(`
      SELECT 
        COALESCE(category, 'unknown') as category,
        COUNT(*) as count,
        COALESCE(ROUND(AVG(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END), 2), 0) as resolution_rate
      FROM reports 
      GROUP BY category
      ORDER BY count DESC
    `);
    
    console.log(`Found ${categoryData.length} categories`);
    
    res.json({
      success: true,
      categories: categoryData
    });
    
  } catch (error) {
    console.error('Category stats error:', error);
    logger.error('Category stats error:', error);
    
    res.status(500).json({
      success: false,
      message: 'Error fetching category statistics',
      ...(process.env.NODE_ENV === 'development' && { error: error.message })
    });
  }
});

// Simple test endpoint for map routes
router.get('/test', async (req, res) => {
  try {
    // Test database connection
    const [result] = await pool.execute('SELECT COUNT(*) as report_count FROM reports');
    const reportCount = result[0].report_count;
    
    res.json({
      success: true,
      message: 'Map routes are working!',
      reportCount: reportCount,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Map test error:', error);
    res.status(500).json({
      success: false,
      message: 'Map test failed',
      error: error.message
    });
  }
});

module.exports = router;