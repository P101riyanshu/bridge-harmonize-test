const express = require('express');
const pool = require('../config/database');
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/roles');
const logger = require('../utils/logger');

const router = express.Router();

// All admin routes require authentication and admin role
router.use(protect);
router.use(authorize('admin'));

// Get system statistics
router.get('/stats', async (req, res) => {
  try {
    // Get total reports count
    const [totalReports] = await pool.execute('SELECT COUNT(*) as count FROM reports');
    
    // Get reports by status
    const [statusCounts] = await pool.execute(`
      SELECT status, COUNT(*) as count 
      FROM reports 
      GROUP BY status
    `);
    
    // Get reports by category
    const [categoryCounts] = await pool.execute(`
      SELECT category, COUNT(*) as count 
      FROM reports 
      GROUP BY category
    `);
    
    // Get recent activity
    const [recentActivity] = await pool.execute(`
      SELECT 
        'report' as type,
        id,
        title,
        created_at as timestamp
      FROM reports 
      UNION ALL
      SELECT 
        'comment' as type,
        id,
        text as title,
        created_at as timestamp
      FROM comments 
      ORDER BY timestamp DESC 
      LIMIT 10
    `);
    
    // Get user statistics
    const [userStats] = await pool.execute(`
      SELECT role, COUNT(*) as count 
      FROM users 
      GROUP BY role
    `);
    
    res.json({
      success: true,
      stats: {
        totalReports: totalReports[0].count,
        byStatus: statusCounts,
        byCategory: categoryCounts,
        recentActivity,
        users: userStats
      }
    });
    
  } catch (error) {
    logger.error('Admin stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching statistics'
    });
  }
});

// Get all users
router.get('/users', async (req, res) => {
  try {
    const [users] = await pool.execute(`
      SELECT id, email, name, role, created_at 
      FROM users 
      ORDER BY created_at DESC
    `);
    
    res.json({
      success: true,
      users
    });
    
  } catch (error) {
    logger.error('Admin users error:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching users'
    });
  }
});

// Update user role
router.put('/users/:id/role', async (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;
    
    const validRoles = ['citizen', 'admin', 'staff_roads', 'staff_sanitation'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid role'
      });
    }
    
    const [result] = await pool.execute(
      'UPDATE users SET role = ? WHERE id = ?',
      [role, id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    res.json({
      success: true,
      message: 'User role updated successfully'
    });
    
  } catch (error) {
    logger.error('Update user role error:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating user role'
    });
  }
});

module.exports = router;