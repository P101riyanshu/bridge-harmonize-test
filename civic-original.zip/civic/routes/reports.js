const express = require('express');
const { body, validationResult } = require('express-validator');
const pool = require('../config/database');
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/roles');
const { upload, handleMulterError } = require('../middleware/upload');
const { uploadToS3 } = require('../services/s3UploadService');
const { sendNotification } = require('../services/notificationService');
const logger = require('../utils/logger');

const router = express.Router();

// Create a new report
router.post('/', 
  protect, 
  upload.single('image'), 
  handleMulterError,
  [
    body('title').trim().isLength({ min: 5, max: 255 }),
    body('description').trim().isLength({ min: 10, max: 1000 }),
    body('category').isIn(['pothole', 'streetlight', 'trash', 'water', 'other']),
    body('latitude').isFloat({ min: -90, max: 90 }),
    body('longitude').isFloat({ min: -180, max: 180 })
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ 
          success: false,
          message: 'Validation failed', 
          errors: errors.array() 
        });
      }

      const { title, description, category, latitude, longitude, address } = req.body;

      let imageUrl = null;
      
      // Upload image to S3 if provided
      if (req.file) {
        try {
          imageUrl = await uploadToS3(req.file);
        } catch (uploadError) {
          console.error('Image upload failed:', uploadError);
          // Continue without image if upload fails
        }
      }

      // Determine priority based on category
      let priority = 'medium';
      if (category === 'water') priority = 'high';
      if (category === 'other') priority = 'low';

      // Insert report into database
      const [result] = await pool.execute(
        `INSERT INTO reports 
         (title, description, category, status, priority, latitude, longitude, address, user_id) 
         VALUES (?, ?, ?, 'submitted', ?, ?, ?, ?, ?)`,
        [title, description, category, priority, latitude, longitude, address, req.user.id]
      );

      // If image was uploaded, add to media table
      if (imageUrl) {
        await pool.execute(
          'INSERT INTO media (report_id, file_url) VALUES (?, ?)',
          [result.insertId, imageUrl]
        );
      }

      // Get the complete report with user info
      const [reports] = await pool.execute(
        `SELECT r.*, u.name as user_name
         FROM reports r 
         LEFT JOIN users u ON r.user_id = u.id 
         WHERE r.id = ?`,
        [result.insertId]
      );

      // Send notification to admin users
      try {
        await sendNotification('new_report', {
          reportId: result.insertId,
          title: title,
          category: category
        });
      } catch (notifyError) {
        console.error('Notification failed:', notifyError);
        // Continue even if notification fails
      }

      logger.info(`New report created: ${title} by user ${req.user.id}`);

      res.status(201).json({
        success: true,
        message: 'Report created successfully',
        report: reports[0]
      });

    } catch (error) {
      console.error('Create report error:', error);
      logger.error('Create report error:', error);
      res.status(500).json({ 
        success: false,
        message: 'Server error creating report',
        ...(process.env.NODE_ENV === 'development' && { error: error.message })
      });
    }
  }
);

// Get all reports with filtering - FIXED VERSION
router.get('/', async (req, res) => {
  try {
    console.log('🔍 Fetching reports with query:', req.query);
    
    const { category, status, priority, userId, page = 1, limit = 20 } = req.query;
    
    // Convert to numbers with validation
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 20)); // Limit to max 100 per page
    const offset = (pageNum - 1) * limitNum;

    // Start with simple query without joins
    let query = 'SELECT * FROM reports WHERE 1=1';
    let params = [];
    let countQuery = 'SELECT COUNT(*) as total FROM reports WHERE 1=1';
    let countParams = [];

    // Add filters
    if (category) {
      query += ' AND category = ?';
      countQuery += ' AND category = ?';
      params.push(category);
      countParams.push(category);
    }
    if (status) {
      query += ' AND status = ?';
      countQuery += ' AND status = ?';
      params.push(status);
      countParams.push(status);
    }
    if (priority) {
      query += ' AND priority = ?';
      countQuery += ' AND priority = ?';
      params.push(priority);
      countParams.push(priority);
    }
    if (userId) {
      query += ' AND user_id = ?';
      countQuery += ' AND user_id = ?';
      params.push(userId);
      countParams.push(userId);
    }

    // Add pagination - FIXED: Use template literals instead of parameterized queries for LIMIT/OFFSET
    query += ` ORDER BY created_at DESC LIMIT ${limitNum} OFFSET ${offset}`;

    console.log('Executing query:', query);
    console.log('With parameters:', params);

    // Execute queries
    const [reports] = await pool.execute(query, params);
    const [countResult] = await pool.execute(countQuery, countParams);
    const total = countResult[0].total;

    console.log(`✅ Found ${reports.length} reports`);

    res.json({
      success: true,
      reports,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        pages: Math.ceil(total / limitNum)
      }
    });

  } catch (error) {
    console.error('❌ Get reports error:');
    console.error('Error message:', error.message);
    console.error('Error code:', error.code);
    console.error('Error sqlMessage:', error.sqlMessage);
    console.error('Error stack:', error.stack);
    
    logger.error('Get reports error:', error);
    
    res.status(500).json({ 
      success: false,
      message: 'Server error fetching reports',
      ...(process.env.NODE_ENV === 'development' && { 
        error: error.message,
        suggestion: 'Check if reports table exists in database'
      })
    });
  }
});

// Get a single report
router.get('/:id', async (req, res) => {
  const { id } = req.params;

  try {
    console.log(`🔍 Fetching report ${id}`);
    
    // Simple query without media join first
    const [reports] = await pool.execute(
      `SELECT r.*, u.name as user_name
       FROM reports r 
       LEFT JOIN users u ON r.user_id = u.id 
       WHERE r.id = ?`,
      [id]
    );

    if (reports.length === 0) {
      return res.status(404).json({ 
        success: false,
        message: 'Report not found' 
      });
    }

    // Try to get media if available
    let media = [];
    try {
      const [mediaResults] = await pool.execute(
        'SELECT * FROM media WHERE report_id = ?',
        [id]
      );
      media = mediaResults;
    } catch (mediaError) {
      console.warn('Media query failed (table might not exist):', mediaError.message);
    }

    // Try to get comments if available
    let comments = [];
    try {
      const [commentResults] = await pool.execute(
        `SELECT c.*, u.name as user_name, u.role as user_role
         FROM comments c 
         LEFT JOIN users u ON c.user_id = u.id 
         WHERE c.report_id = ? 
         ORDER BY c.created_at ASC`,
        [id]
      );
      comments = commentResults;
    } catch (commentError) {
      console.warn('Comments query failed (table might not exist):', commentError.message);
    }

    // Add media to report object
    const reportWithMedia = {
      ...reports[0],
      image_url: media.length > 0 ? media[0].file_url : null
    };

    res.json({
      success: true,
      report: reportWithMedia,
      comments
    });

  } catch (error) {
    console.error('Get report error:', error);
    logger.error('Get report error:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error fetching report',
      ...(process.env.NODE_ENV === 'development' && { error: error.message })
    });
  }
});

// Update a report (admin/staff only)
router.put('/:id', 
  protect, 
  authorize('admin', 'staff_roads', 'staff_sanitation'),
  [
    body('status').optional().isIn(['submitted', 'acknowledged', 'in_progress', 'resolved', 'rejected']),
    body('priority').optional().isIn(['low', 'medium', 'high'])
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ 
          success: false,
          message: 'Validation failed', 
          errors: errors.array() 
        });
      }

      const { id } = req.params;
      const { status, priority, assigned_to } = req.body;

      // Build dynamic update query
      let updateFields = [];
      let updateValues = [];
      
      if (status) {
        updateFields.push('status = ?');
        updateValues.push(status);
      }
      
      if (priority) {
        updateFields.push('priority = ?');
        updateValues.push(priority);
      }
      
      if (assigned_to) {
        updateFields.push('assigned_to = ?');
        updateValues.push(assigned_to);
      }
      
      if (updateFields.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'No fields to update'
        });
      }
      
      // Add updated_at timestamp
      updateFields.push('updated_at = CURRENT_TIMESTAMP');
      
      // Add report ID to values
      updateValues.push(id);

      const [result] = await pool.execute(
        `UPDATE reports SET ${updateFields.join(', ')} WHERE id = ?`,
        updateValues
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ 
          success: false,
          message: 'Report not found' 
        });
      }

      // Get the updated report
      const [reports] = await pool.execute(
        `SELECT r.*, u.name as user_name
         FROM reports r 
         LEFT JOIN users u ON r.user_id = u.id 
         WHERE r.id = ?`,
        [id]
      );

      // Send notification if status changed to resolved
      if (status === 'resolved') {
        try {
          const report = reports[0];
          await sendNotification('report_resolved', {
            reportId: id,
            title: report.title,
            userId: report.user_id
          });
        } catch (notifyError) {
          console.error('Notification failed:', notifyError);
        }
      }

      logger.info(`Report ${id} updated by user ${req.user.id}`);

      res.json({
        success: true,
        message: 'Report updated successfully',
        report: reports[0]
      });

    } catch (error) {
      console.error('Update report error:', error);
      logger.error('Update report error:', error);
      res.status(500).json({ 
        success: false,
        message: 'Server error updating report',
        ...(process.env.NODE_ENV === 'development' && { error: error.message })
      });
    }
  }
);

// Add a comment to a report
router.post('/:id/comments', 
  protect,
  [
    body('text').trim().isLength({ min: 1, max: 500 }),
    body('isPublic').optional().isBoolean()
  ],
  async (req, res) => {
    try {
      // Check for validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ 
          success: false,
          message: 'Validation failed', 
          errors: errors.array() 
        });
      }

      const { id } = req.params;
      const { text, isPublic = true } = req.body;

      // Check if report exists
      const [reports] = await pool.execute('SELECT * FROM reports WHERE id = ?', [id]);
      if (reports.length === 0) {
        return res.status(404).json({ 
          success: false,
          message: 'Report not found' 
        });
      }

      // Insert comment
      const [result] = await pool.execute(
        'INSERT INTO comments (report_id, user_id, text, is_public) VALUES (?, ?, ?, ?)',
        [id, req.user.id, text, isPublic]
      );

      // Get the complete comment with user info
      const [comments] = await pool.execute(
        `SELECT c.*, u.name as user_name, u.role as user_role
         FROM comments c 
         LEFT JOIN users u ON c.user_id = u.id 
         WHERE c.id = ?`,
        [result.insertId]
      );

      logger.info(`Comment added to report ${id} by user ${req.user.id}`);

      res.status(201).json({
        success: true,
        message: 'Comment added successfully',
        comment: comments[0]
      });

    } catch (error) {
      console.error('Add comment error:', error);
      logger.error('Add comment error:', error);
      
      // Check if comments table exists
      if (error.code === 'ER_NO_SUCH_TABLE') {
        return res.status(500).json({ 
          success: false,
          message: 'Comments feature not configured yet'
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: 'Server error adding comment',
        ...(process.env.NODE_ENV === 'development' && { error: error.message })
      });
    }
  }
);

module.exports = router;