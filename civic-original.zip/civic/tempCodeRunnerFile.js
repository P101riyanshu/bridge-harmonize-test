const mysql = require('mysql2');

console.log('🧪 Testing database connection...');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '7017341800@Pr',
  database: 'civic_issue_db'
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Database connection failed:');
    console.error('Error message:', err.message);
    console.error('Error code:', err.code);
    
    if (err.code === 'ER_ACCESS_DENIED_ERROR') {
      console.error('💡 Solution: Check your MySQL username and password');
    } else if (err.code === 'ER_BAD_DB_ERROR') {
      console.error('💡 Solution: Database does not exist. Create it first.');
    } else if (err.code === 'ECONNREFUSED') {
      console.error('💡 Solution: MySQL server is not running');
    }
    
    process.exit(1);
  }
  
  console.log('✅ Connected to MySQL database');
  
  // Check if users table exists
  connection.query('SHOW TABLES LIKE "users"', (err, results) => {
    if (err) {
      console.error('Error checking tables:', err);
    } else if (results.length === 0) {
      console.log('❌ Users table does not exist');
    } else {
      console.log('✅ Users table exists');
    }
    
    connection.end();
    process.exit(0);
  });
});