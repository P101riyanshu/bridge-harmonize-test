// // // const mysql = require('mysql2');
// // // const logger = require('../utils/logger');

// // // // Create connection pool
// // // const pool = mysql.createPool({
// // //   host: process.env.DB_HOST,
// // //   user: process.env.DB_USER,
// // //   password: process.env.DB_PASSWORD,
// // //   database: process.env.DB_NAME,
// // //   port: process.env.DB_PORT || 3306,
// // //   waitForConnections: true,
// // //   connectionLimit: 10,
// // //   queueLimit: 0,
// // //   charset: 'utf8mb4',
// // //   timezone: '+00:00'
// // // });

// // // // Convert pool to use promises
// // // const promisePool = pool.promise();

// // // // Test the database connection
// // // promisePool.getConnection()
// // //   .then(connection => {
// // //     logger.info('Connected to MySQL database');
// // //     connection.release();
// // //   })
// // //   .catch(err => {
// // //     logger.error('Error connecting to MySQL database:', err.message);
// // //   });

// // // module.exports = promisePool;
// // const mysql = require('mysql2');
// // const logger = require('../utils/logger');

// // const pool = mysql.createPool({
// //   host: process.env.DB_HOST || 'localhost',
// //   user: process.env.DB_USER || 'root',
// //   password: process.env.DB_PASSWORD || '',
// //   database: process.env.DB_NAME || 'civic_issue_db',
// //   port: process.env.DB_PORT || 3306,
// //   waitForConnections: true,
// //   connectionLimit: 10,
// //   queueLimit: 0,
// //   connectTimeout: 60000, // Increase timeout
// //   acquireTimeout: 60000, // Increase acquisition timeout
// //   timeout: 60000, // Increase timeout
// //   reconnect: true // Enable reconnection
// // });

// // // Test connection
// // pool.getConnection((err, connection) => {
// //   if (err) {
// //     logger.error('Database connection failed:', err);
// //     console.error('Database connection error:', err.message);
// //   } else {
// //     logger.info('Database connected successfully');
// //     console.log('Database connected successfully');
// //     connection.release();
// //   }
// // });

// // const promisePool = pool.promise();
// // module.exports = promisePool;

// const mysql = require('mysql2');
// const logger = require('../utils/logger');

// // Create connection pool
// const pool = mysql.createPool({
//   host: process.env.DB_HOST || 'localhost',
//   user: process.env.DB_USER || 'root',
//   password: process.env.DB_PASSWORD || '', // Empty password if not set
//   database: process.env.DB_NAME || 'civic_issue_db',
//   port: process.env.DB_PORT || 3306,
//   waitForConnections: true,
//   connectionLimit: 10,
//   queueLimit: 0,
//   connectTimeout: 60000,
//   acquireTimeout: 60000,
//   timeout: 60000,
//   reconnect: true
// });

// // Test connection
// pool.getConnection((err, connection) => {
//   if (err) {
//     console.error('❌ Database connection failed:', err.message);
//     logger.error('Database connection error:', err);
//   } else {
//     console.log('✅ Database connected successfully');
//     logger.info('Connected to MySQL database');
//     connection.release();
//   }
// });

// const promisePool = pool.promise();
// module.exports = promisePool;


const mysql = require('mysql2');
const logger = require('../utils/logger');

// Create connection pool with correct options
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'civic_issue_db',
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  // These are the correct pool options (remove the invalid ones)
  acquireTimeout: 60000, // Correct pool option
  timeout: 60000,        // Correct pool option
  // Remove 'reconnect' as it's not a valid option for pools
});

// Convert to promise-based interface
const promisePool = pool.promise();

// Test connection
pool.getConnection((err, connection) => {
  if (err) {
    console.error('❌ Database connection failed:', err.message);
    logger.error('Database connection error:', err);
  } else {
    console.log('✅ Database connected successfully');
    logger.info('Connected to MySQL database');
    connection.release();
  }
});

module.exports = promisePool;