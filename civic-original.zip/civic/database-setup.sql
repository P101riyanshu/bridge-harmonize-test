-- Create database
CREATE DATABASE IF NOT EXISTS civic_issue_db;
USE civic_issue_db;

-- Users table (must be created first since other tables reference it)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role ENUM('citizen', 'admin', 'staff_roads', 'staff_sanitation') DEFAULT 'citizen',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_role (role)
);

-- Reports table
CREATE TABLE IF NOT EXISTS reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category ENUM('pothole', 'streetlight', 'trash', 'water', 'other') NOT NULL,
    status ENUM('submitted', 'acknowledged', 'in_progress', 'resolved', 'rejected') DEFAULT 'submitted',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    address TEXT,
    user_id INT NOT NULL,
    assigned_to INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_latitude (latitude),
    INDEX idx_longitude (longitude),
    INDEX idx_location (latitude, longitude),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_created_at (created_at)
);

-- Add foreign key constraints to reports table (after both tables exist)
ALTER TABLE reports 
ADD FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
ADD FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL;

-- Media table
CREATE TABLE IF NOT EXISTS media (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_id INT NOT NULL,
    file_url TEXT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_report_id (report_id)
);

-- Add foreign key constraint to media table
ALTER TABLE media 
ADD FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE CASCADE;

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_id INT NOT NULL,
    user_id INT NOT NULL,
    text TEXT NOT NULL,
    is_public BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_report_id (report_id),
    INDEX idx_created_at (created_at)
);

-- Add foreign key constraints to comments table
ALTER TABLE comments 
ADD FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE CASCADE,
ADD FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    related_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
);

-- Add foreign key constraint to notifications table
ALTER TABLE notifications 
ADD FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- Insert sample admin user (password: admin123)
INSERT INTO users (email, password_hash, name, role) VALUES
('admin@city.gov', '$2a$10$rOzZuj5UvmUfktX3sF/qj.FfB.7p7qK9qk6Jk8q8q8q8q8q8q8q8q', 'City Administrator', 'admin');

-- Insert sample staff users (password: staff123)
INSERT INTO users (email, password_hash, name, role) VALUES
('roads@city.gov', '$2a$10$rOzZuj5UvmUfktX3sF/qj.FfB.7p7qK9qk6Jk8q8q8q8q8q8q8q8q', 'Roads Department', 'staff_roads'),
('sanitation@city.gov', '$2a$10$rOzZuj5UvmUfktX3sF/qj.FfB.7p7qK9qk6Jk8q8q8q8q8q8q8q8q', 'Sanitation Department', 'staff_sanitation');

-- Insert sample citizen user (password: citizen123)
INSERT INTO users (email, password_hash, name, role) VALUES
('citizen@example.com', '$2a$10$rOzZuj5UvmUfktX3sF/qj.FfB.7p7qK9qk6Jk8q8q8q8q8q8q8q8q', 'John Citizen', 'citizen');

-- Insert sample reports
INSERT INTO reports (title, description, category, status, priority, latitude, longitude, address, user_id) VALUES
('Pothole on Main Street', 'Large pothole near the intersection of Main and 5th Street. It''s getting deeper with each rain.', 'pothole', 'submitted', 'high', 40.7128, -74.0060, '123 Main Street', 4),
('Broken streetlight', 'Streetlight not working on Oak Avenue between 2nd and 3rd Street. It''s completely dark at night.', 'streetlight', 'in_progress', 'medium', 40.7138, -74.0070, '456 Oak Avenue', 4),
('Overflowing trash bin', 'Public trash bin overflowing in Central Park near the fountain. Trash is scattered around.', 'trash', 'acknowledged', 'medium', 40.7148, -74.0080, 'Central Park', 4);

-- Insert sample media
INSERT INTO media (report_id, file_url) VALUES
(1, 'https://example.com/images/pothole1.jpg'),
(2, 'https://example.com/images/streetlight1.jpg'),
(3, 'https://example.com/images/trash1.jpg');

-- Insert sample comments
INSERT INTO comments (report_id, user_id, text, is_public) VALUES
(1, 1, 'Issue has been assigned to roads department for assessment.', TRUE),
(2, 2, 'Maintenance crew scheduled for next Tuesday.', TRUE),
(3, 3, 'Sanitation team will address this within 24 hours.', TRUE);