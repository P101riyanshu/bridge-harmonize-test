const pool = require('../config/database');
const logger = require('../utils/logger');
const { sendNewReportEmail } = require('./emailService');

/**
 * Send notification to users
 * @param {string} type - Type of notification
 * @param {object} data - Notification data
 */
const sendNotification = async (type, data) => {
  try {
    let userIds = [];
    let title = '';
    let message = '';

    // Determine notification details based on type
    switch (type) {
      case 'new_report':
        title = 'New Report Submitted';
        message = `A new ${data.category} report has been submitted: ${data.title}`;
        
        // Get all admin users
        const [admins] = await pool.execute(
          'SELECT id, email FROM users WHERE role IN ("admin", "staff_roads", "staff_sanitation")'
        );
        userIds = admins.map(admin => admin.id);
        
        // Send email to admins (in production)
        if (process.env.NODE_ENV === 'production') {
          for (const admin of admins) {
            await sendNewReportEmail({
              category: data.category,
              title: data.title,
              description: data.description || '',
              address: data.address || '',
              latitude: data.latitude,
              longitude: data.longitude,
              user_name: 'Citizen User'
            }, admin.email);
          }
        }
        break;

      case 'report_resolved':
        title = 'Report Resolved';
        message = `Your report "${data.title}" has been resolved.`;
        userIds = [data.userId]; // Notify the report owner
        break;

      case 'status_update':
        title = 'Report Status Updated';
        message = `The status of report "${data.title}" has been updated to ${data.status}.`;
        userIds = [data.userId]; // Notify the report owner
        break;

      default:
        logger.warn(`Unknown notification type: ${type}`);
        return;
    }
    
    // Create notifications for all target users
    for (const userId of userIds) {
      await pool.execute(
        'INSERT INTO notifications (user_id, type, title, message, related_id) VALUES (?, ?, ?, ?, ?)',
        [userId, type, title, message, data.reportId || null]
      );
    }

    logger.info(`Sent ${type} notification to ${userIds.length} users`);
    
  } catch (error) {
    logger.error('Error sending notification:', error);
  }
};

// ... rest of the functions (getUserNotifications, markAsRead)

module.exports = {
  sendNotification,
  getUserNotifications,
  markAsRead
};