const pool = require('../config/database');
const logger = require('../utils/logger');

/**
 * Send notification to users
 * @param {string} type - Type of notification
 * @param {object} data - Notification data
 */
const sendNotification = async (type, data) => {
  try {
    let userIds = [];
    let title = '';
    let message = '';

    // Determine notification details based on type
    switch (type) {
      case 'new_report':
        title = 'New Report Submitted';
        message = `A new ${data.category} report has been submitted: ${data.title}`;
        
        // Get all admin users
        const [admins] = await pool.execute(
          'SELECT id FROM users WHERE role IN ("admin", "staff_roads", "staff_sanitation")'
        );
        userIds = admins.map(admin => admin.id);
        break;

      case 'report_resolved':
        title = 'Report Resolved';
        message = `Your report "${data.title}" has been resolved.`;
        userIds = [data.userId]; // Notify the report owner
        break;

      case 'status_update':
        title = 'Report Status Updated';
        message = `The status of report "${data.title}" has been updated to ${data.status}.`;
        userIds = [data.userId]; // Notify the report owner
        break;

      default:
        logger.warn(`Unknown notification type: ${type}`);
        return;
    }

    // Create notifications for all target users
    for (const userId of userIds) {
      await pool.execute(
        'INSERT INTO notifications (user_id, type, title, message, related_id) VALUES (?, ?, ?, ?, ?)',
        [userId, type, title, message, data.reportId || null]
      );
    }

    logger.info(`Sent ${type} notification to ${userIds.length} users`);
    
  } catch (error) {
    logger.error('Error sending notification:', error);
  }
};

/**
 * Get notifications for a user
 * @param {number} userId - User ID
 * @param {number} limit - Maximum number of notifications to return
 */
const getUserNotifications = async (userId, limit = 20) => {
  try {
    const [notifications] = await pool.execute(
      'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
      [userId, limit]
    );
    
    return notifications;
  } catch (error) {
    logger.error('Error getting user notifications:', error);
    throw error;
  }
};

/**
 * Mark notification as read
 * @param {number} notificationId - Notification ID
 * @param {number} userId - User ID (for security validation)
 */
const markAsRead = async (notificationId, userId) => {
  try {
    const [result] = await pool.execute(
      'UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?',
      [notificationId, userId]
    );
    
    return result.affectedRows > 0;
  } catch (error) {
    logger.error('Error marking notification as read:', error);
    throw error;
  }
};

module.exports = {
  sendNotification,
  getUserNotifications,
  markAsRead
};