const http = require('http');

const API_BASE = 'http://localhost:5000/api';
let authToken = null;
let adminToken = null;

// Test data
const testUser = {
  email: 't00admin@example.com',
  password: 'test123',
  name: 'Test Admin'
};

const testReport = {
  title: 'Test Report API',
  description: 'This is a test report for API testing',
  category: 'pothole',
  latitude: 40.7128,
  longitude: -74.0060,
  address: 'Test Location'
};

async function testEndpoint(test) {
  return new Promise((resolve) => {
    console.log(`\n🔍 Testing: ${test.name}`);
    console.log(`   ${test.method} ${test.path}`);

    const url = new URL(test.path, API_BASE);
    if (test.query) {
      Object.entries(test.query).forEach(([key, value]) => {
        url.searchParams.append(key, value);
      });
    }

    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method: test.method,
      headers: {
        'Content-Type': 'application/json',
        ...test.headers
      }
    };

    // 🔐 Attach tokens automatically
    if (test.useAdmin && adminToken) {
      options.headers['Authorization'] = `Bearer ${adminToken}`;
      console.log(`   🔐 Using admin token: ${adminToken.substring(0, 20)}...`);
    } else if (authToken && test.requiresAuth !== false) {
      options.headers['Authorization'] = `Bearer ${authToken}`;
      console.log(`   🔐 Using user token: ${authToken.substring(0, 20)}...`);
    }

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        let response;
        try {
          response = JSON.parse(data);
        } catch (e) {
          response = { raw: data };
        }

        const success = res.statusCode === test.expectedStatus;
        const statusIcon = success ? '✅' : '❌';

        console.log(`   ${statusIcon} Status: ${res.statusCode} (expected ${test.expectedStatus})`);

        if (!success) {
          console.log(`   Response:`, JSON.stringify(response, null, 2));
          if (response.error) {
            console.log(`   Error: ${response.error}`);
          }
        } else if (test.name.includes('User login') && response.token) {
          authToken = response.token;
          console.log(`   🔐 User token received: ${authToken.substring(0, 20)}...`);
        } else if (test.name.includes('Admin login') && response.token) {
          adminToken = response.token;
          console.log(`   🔐 Admin token received: ${adminToken.substring(0, 20)}...`);
        }

        resolve({ success, response });
      });
    });

    req.on('error', (error) => {
      console.log(`   ❌ Request failed: ${error.message}`);
      resolve({ success: false, error: error.message });
    });

    if (test.body) {
      req.write(JSON.stringify(test.body));
    }

    req.end();
  });
}

async function runAllTests() {
  console.log('🚀 Starting Comprehensive API Tests');
  console.log('='.repeat(50));

  const tests = [
    // Basic connectivity tests
    {
      name: 'Root endpoint',
      method: 'GET',
      path: '/',
      expectedStatus: 200
    },
    {
      name: 'Database connection test',
      method: 'GET',
      path: '/api/test-db',
      expectedStatus: 200
    },

    // Auth tests
    {
      name: 'User registration',
      method: 'POST',
      path: '/api/auth/register',
      body: testUser,
      expectedStatus: 201
    },
    {
      name: 'User login',
      method: 'POST',
      path: '/api/auth/login',
      body: { email: testUser.email, password: testUser.password },
      expectedStatus: 200
    },

    // Test without auth (should fail)
    {
      name: 'Get profile without auth (should fail)',
      method: 'GET',
      path: '/api/auth/me',
      requiresAuth: false,
      expectedStatus: 401
    },

    // Auth tests - with token
    {
      name: 'Get profile with auth',
      method: 'GET',
      path: '/api/auth/me',
      expectedStatus: 200
    },

    // Reports tests
    {
      name: 'Get all reports',
      method: 'GET',
      path: '/api/reports',
      expectedStatus: 200
    },
    {
      name: 'Create new report',
      method: 'POST',
      path: '/api/reports',
      body: testReport,
      expectedStatus: 201
    },
    {
      name: 'Get single report',
      method: 'GET',
      path: '/api/reports/1',
      expectedStatus: 200
    },

    // Map tests
    {
      name: 'Get map clusters',
      method: 'GET',
      path: '/api/map/clusters',
      query: { zoom: '12' },
      expectedStatus: 200
    },
    {
      name: 'Get heatmap data',
      method: 'GET',
      path: '/api/map/heatmap',
      expectedStatus: 200
    },

    // Admin login
    {
      name: 'Admin login',
      method: 'POST',
      path: '/api/auth/login',
      body: { email: 'admin@city.gov', password: 'admin123' },
      expectedStatus: 200
    },

    // Admin tests
    {
      name: 'Get admin stats',
      method: 'GET',
      path: '/api/admin/stats',
      expectedStatus: 200,
      useAdmin: true
    },
    {
      name: 'Get all users',
      method: 'GET',
      path: '/api/admin/users',
      expectedStatus: 200,
      useAdmin: true
    }
  ];

  let passed = 0;
  let failed = 0;
  const results = [];

  for (const test of tests) {
    const result = await testEndpoint(test);
    results.push({ ...test, result });

    if (result.success) {
      passed++;
    } else {
      failed++;
    }

    // Small delay between tests
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  console.log('\n' + '='.repeat(50));
  console.log('📊 TEST RESULTS:');
  console.log(`✅ Passed: ${passed}`);
  console.log(`❌ Failed: ${failed}`);
  console.log('='.repeat(50));

  if (failed > 0) {
    console.log('\n🔍 FAILED TESTS DETAILS:');
    results.filter(r => !r.result.success).forEach((test, index) => {
      console.log(`\n${index + 1}. ${test.name}`);
      console.log(`   Endpoint: ${test.method} ${test.path}`);
      if (test.result.error) {
        console.log(`   Error: ${test.result.error}`);
      }
    });
  }

  if (failed === 0) {
    console.log('\n🎉 All tests passed! Your API is working correctly.');
  } else {
    console.log(`\n⚠️  ${failed} test(s) failed. Check the details above.`);
  }

  return { passed, failed, results };
}

// Run tests if executed directly
if (require.main === module) {
  runAllTests().then(({ passed, failed }) => {
    process.exit(failed > 0 ? 1 : 0);
  }).catch(error => {
    console.error('Test runner error:', error);
    process.exit(1);
  });
}

module.exports = { runAllTests };
