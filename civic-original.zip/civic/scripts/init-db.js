const mysql = require('mysql2');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');

// Load env vars
dotenv.config();

// Read SQL file
const sqlPath = path.join(__dirname, '..', 'database-setup.sql');
const sql = fs.readFileSync(sqlPath, 'utf8');

// Create connection
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT || 3306,
  multipleStatements: true
});

console.log('Initializing database...');

// Connect to MySQL and execute SQL script
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err.message);
    process.exit(1);
  }

  console.log('Connected to MySQL server');

  // Create database if it doesn't exist
  connection.query(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME}`, (err) => {
    if (err) {
      console.error('Error creating database:', err.message);
      connection.end();
      process.exit(1);
    }

    console.log(`Database ${process.env.DB_NAME} created or already exists`);

    // Switch to the database
    connection.query(`USE ${process.env.DB_NAME}`, (err) => {
      if (err) {
        console.error('Error switching database:', err.message);
        connection.end();
        process.exit(1);
      }

      console.log('Using database:', process.env.DB_NAME);

      // Execute SQL script
      connection.query(sql, (err) => {
        if (err) {
          console.error('Error executing SQL script:', err.message);
          connection.end();
          process.exit(1);
        }

        console.log('Database setup completed successfully');
        connection.end();
        process.exit(0);
      });
    });
  });
});