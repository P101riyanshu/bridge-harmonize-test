// src/components/DashboardPage.js
import React, { useState } from 'react';

const DashboardPage = () => {
  const [activeTab, setActiveTab] = useState('submit-complaint');
  const [imagePreview, setImagePreview] = useState(null);
  const [showManualLocation, setShowManualLocation] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [userLocation, setUserLocation] = useState('Automatically detecting your location...');

  // Simulate location detection
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setUserLocation('Sector 15, Noida, Uttar Pradesh');
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
  };

  const handleVoiceRecord = () => {
    setIsRecording(true);
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    alert('Voice recording added!');
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const handleSubmitComplaint = (e) => {
    e.preventDefault();
    alert('Complaint submitted successfully!');
    // Reset form
    e.target.reset();
    setImagePreview(null);
    setShowManualLocation(false);
    setIsRecording(false);
  };

  return (
    <div className="page">
      <section className="py-16 bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">User Dashboard</h2>
          <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">Manage your reports, track their status, and see your contribution points.</p>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden max-w-6xl mx-auto">
            <div className="border-b border-gray-200">
              <div className="flex overflow-x-auto">
                <button 
                  className={`px-6 py-4 font-medium ${activeTab === 'submit-complaint' ? 'border-b-2 border-primary text-primary' : 'text-gray-500'}`}
                  onClick={() => handleTabChange('submit-complaint')}
                >
                  Submit Complaint
                </button>
                <button 
                  className={`px-6 py-4 font-medium ${activeTab === 'grievance-status' ? 'border-b-2 border-primary text-primary' : 'text-gray-500'}`}
                  onClick={() => handleTabChange('grievance-status')}
                >
                  Grievance Status
                </button>
                <button 
                  className={`px-6 py-4 font-medium ${activeTab === 'your-points' ? 'border-b-2 border-primary text-primary' : 'text-gray-500'}`}
                  onClick={() => handleTabChange('your-points')}
                >
                  Your Points
                </button>
              </div>
            </div>
            
            {/* Submit Complaint Tab */}
            {activeTab === 'submit-complaint' && (
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-6">Report a New Issue</h3>
                
                <form onSubmit={handleSubmitComplaint}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <div className="mb-4">
                        <label className="block text-gray-700 mb-2">Upload Photo</label>
                        <div 
                          className="border-2 border-dashed border-gray-300 rounded-lg h-40 flex items-center justify-center cursor-pointer"
                          onClick={() => document.getElementById('photo-upload').click()}
                        >
                          {imagePreview ? (
                            <div className="text-center">
                              <img src={imagePreview} alt="Preview" className="h-32 rounded-lg shadow-md mx-auto" />
                              <button 
                                type="button" 
                                className="mt-2 text-red-500 text-sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleRemoveImage();
                                }}
                              >
                                Remove
                              </button>
                            </div>
                          ) : (
                            <div className="text-center">
                              <i className="fas fa-camera text-3xl text-gray-400 mb-2"></i>
                              <p className="text-gray-500">Click to upload or drag and drop</p>
                              <p className="text-gray-400 text-sm">JPEG, PNG (Max 5MB)</p>
                            </div>
                          )}
                          <input 
                            type="file" 
                            id="photo-upload" 
                            className="hidden" 
                            accept="image/*" 
                            onChange={handleImageUpload}
                          />
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <label className="block text-gray-700 mb-2">Location</label>
                        <div className="flex items-center bg-gray-100 rounded-lg p-3">
                          <i className="fas fa-map-marker-alt text-primary mr-2"></i>
                          <span className="text-gray-600">{userLocation}</span>
                          <button 
                            type="button"
                            className="ml-auto text-sm text-primary font-medium"
                            onClick={() => setShowManualLocation(!showManualLocation)}
                          >
                            Change
                          </button>
                        </div>
                      </div>
                      
                      {showManualLocation && (
                        <div className="mb-4">
                          <label className="block text-gray-700 mb-2">Enter Address</label>
                          <input 
                            type="text" 
                            className="w-full bg-gray-100 rounded-lg p-3 focus:ring-2 focus:ring-primary focus:outline-none" 
                            placeholder="Enter your address"
                          />
                        </div>
                      )}
                    </div>
                    
                    <div>
                      <div className="mb-4">
                        <label className="block text-gray-700 mb-2">Issue Category</label>
                        <select className="w-full bg-gray-100 rounded-lg p-3 focus:ring-2 focus:ring-primary focus:outline-none" required>
                          <option value="">Select a category</option>
                          <option value="pothole">Pothole</option>
                          <option value="garbage">Garbage Accumulation</option>
                          <option value="streetlight">Street Light Issue</option>
                          <option value="water">Water Supply Problem</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                      
                      <div className="mb-4">
                        <label className="block text-gray-700 mb-2">Issue Description</label>
                        <textarea 
                          className="w-full bg-gray-100 rounded-lg p-4 focus:ring-2 focus:ring-primary focus:outline-none" 
                          rows="5" 
                          placeholder="Describe the issue in detail..."
                          required
                        ></textarea>
                      </div>
                      
                      <div className="flex items-center mb-6">
                        <button 
                          type="button"
                          className="mr-3 w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center hover:bg-gray-300 transition"
                          onClick={handleVoiceRecord}
                        >
                          <i className="fas fa-microphone text-gray-600"></i>
                        </button>
                        <span className="text-sm text-gray-500">Or add voice explanation</span>
                        {isRecording && (
                          <div className="ml-auto flex items-center">
                            <span className="text-red-500 text-sm mr-2">Recording...</span>
                            <button 
                              type="button"
                              className="text-red-500"
                              onClick={handleStopRecording}
                            >
                              <i className="fas fa-stop-circle"></i>
                            </button>
                          </div>
                        )}
                      </div>
                      
                      <button type="submit" className="w-full btn-primary text-white py-3 rounded-lg font-medium transition">
                        Submit Report
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            )}
            
            {/* Grievance Status Tab */}
            {activeTab === 'grievance-status' && (
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-6">Your Reported Issues</h3>
                
                <div className="flex justify-between mb-8 relative">
                  <div className="absolute top-3 left-0 right-0 h-1 bg-gray-200 z-0"></div>
                  <div className="relative z-10 text-center">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white mx-auto mb-2">
                      <i className="fas fa-check text-xs"></i>
                    </div>
                    <div className="text-xs font-medium">Submitted</div>
                  </div>
                  <div className="relative z-10 text-center">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white mx-auto mb-2">
                      <i className="fas fa-check text-xs"></i>
                    </div>
                    <div className="text-xs font-medium">Acknowledged</div>
                  </div>
                  <div className="relative z-10 text-center">
                    <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white mx-auto mb-2">
                      <i className="fas fa-clock text-xs"></i>
                    </div>
                    <div className="text-xs font-medium">In Progress</div>
                  </div>
                  <div className="relative z-10 text-center">
                    <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white mx-auto mb-2">
                      <i className="fas fa-times text-xs"></i>
                    </div>
                    <div className="text-xs font-medium">Resolved</div>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="bg-gray-50 rounded-2xl p-6 card-hover">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">Pothole on Main Street</h3>
                        <p className="text-gray-600 text-sm">Reported on April 12, 2023</p>
                      </div>
                      <span className="status-badge status-progress">In Progress</span>
                    </div>
                    <div className="mt-4 text-sm">
                      <div className="flex items-center mb-1">
                        <i className="fas fa-map-marker-alt text-gray-400 mr-2"></i>
                        <span>Near Central Park, Sector 15</span>
                      </div>
                      <div className="flex items-center">
                        <i className="fas fa-info-circle text-gray-400 mr-2"></i>
                        <span>Department of Public Works has been assigned</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-2xl p-6 card-hover">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">Garbage Accumulation</h3>
                        <p className="text-gray-600 text-sm">Reported on April 10, 2023</p>
                      </div>
                      <span className="status-badge status-resolved">Resolved</span>
                    </div>
                    <div className="mt-4 text-sm">
                      <div className="flex items-center mb-1">
                        <i className="fas fa-map-marker-alt text-gray-400 mr-2"></i>
                        <span>Near Community Center, Sector 22</span>
                      </div>
                      <div className="flex items-center">
                        <i className="fas fa-info-circle text-gray-400 mr-2"></i>
                        <span>Cleaned by sanitation department on April 11, 2023</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-2xl p-6 card-hover">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">Broken Street Light</h3>
                        <p className="text-gray-600 text-sm">Reported on April 15, 2023</p>
                      </div>
                      <span className="status-badge status-acknowledged">Acknowledged</span>
                    </div>
                    <div className="mt-4 text-sm">
                      <div className="flex items-center mb-1">
                        <i className="fas fa-map-marker-alt text-gray-400 mr-2"></i>
                        <span>Outside Sector 12 Market</span>
                      </div>
                      <div className="flex items-center">
                        <i className="fas fa-info-circle text-gray-400 mr-2"></i>
                        <span>Waiting for electrician assignment</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Your Points Tab */}
            {activeTab === 'your-points' && (
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-6">Your Contribution Points</h3>
                
                <div className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-6 text-white mb-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-2xl font-semibold">175 Points</h3>
                      <p className="opacity-90">Keep contributing to unlock new levels</p>
                    </div>
                    <div className="text-3xl font-bold">🥈</div>
                  </div>
                </div>
                
                <div className="mb-6">
                  <div className="flex justify-between text-sm mb-2">
                    <span>Level 2: Community Helper</span>
                    <span>200/200 pts</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-green-500 h-2.5 rounded-full" style={{width: '100%'}}></div>
                  </div>
                </div>
                
                <div className="mb-8">
                  <div className="flex justify-between text-sm mb-2">
                    <span>Level 3: Civic Champion</span>
                    <span>175/400 pts</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className="bg-yellow-500 h-2.5 rounded-full" style={{width: '44%'}}></div>
                  </div>
                </div>
                
                <h4 className="text-lg font-semibold mb-4">Recent Points Earned</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-4">
                        <i className="fas fa-check-circle"></i>
                      </div>
                      <div>
                        <p className="font-medium">Garbage issue resolved</p>
                        <p className="text-sm text-gray-500">April 11, 2023</p>
                      </div>
                    </div>
                    <span className="text-primary font-bold">+15 points</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 mr-4">
                        <i className="fas fa-bullhorn"></i>
                      </div>
                      <div>
                        <p className="font-medium">New issue reported</p>
                        <p className="text-sm text-gray-500">April 15, 2023</p>
                      </div>
                    </div>
                    <span className="text-primary font-bold">+10 points</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 mr-4">
                        <i className="fas fa-share-alt"></i>
                      </div>
                      <div>
                        <p className="font-medium">Shared on social media</p>
                        <p className="text-sm text-gray-500">April 8, 2023</p>
                      </div>
                    </div>
                    <span className="text-primary font-bold">+5 points</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardPage;