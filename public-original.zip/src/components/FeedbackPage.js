// src/components/FeedbackPage.js
import React, { useState } from 'react';

const FeedbackPage = () => {
  const [rating, setRating] = useState(0);

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Thank you for your feedback!');
    // Reset form
    e.target.reset();
    setRating(0);
  };

  const handleRatingClick = (value) => {
    setRating(value);
  };

  return (
    <div className="page">
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">We'd Love Your Feedback</h2>
          <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">Your suggestions help us improve Saiyaara and serve our community better.</p>
          
          <div className="max-w-3xl mx-auto bg-gray-50 rounded-2xl p-8 shadow-md">
            <form id="feedback-form" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-gray-700 mb-2" htmlFor="name">Full Name</label>
                  <input type="text" id="name" className="w-full bg-white rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" placeholder="Enter your name" required />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2" htmlFor="email">Email Address</label>
                  <input type="email" id="email" className="w-full bg-white rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" placeholder="Enter your email" required />
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-gray-700 mb-2" htmlFor="subject">Subject</label>
                <input type="text" id="subject" className="w-full bg-white rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" placeholder="What is your feedback about?" required />
              </div>
              
              <div className="mb-6">
                <label className="block text-gray-700 mb-2" htmlFor="message">Your Feedback</label>
                <textarea id="message" rows="5" className="w-full bg-white rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" placeholder="Please share your thoughts with us..." required></textarea>
              </div>
              
              <div className="mb-6">
                <label className="block text-gray-700 mb-2">How would you rate your experience with Saiyaara?</label>
                <div className="flex space-x-2">
                  {[1, 2, 3, 4, 5].map((value) => (
                    <button 
                      key={value}
                      type="button" 
                      className={`w-10 h-10 rounded-full transition ${rating >= value ? 'bg-primary text-white' : 'bg-gray-200 hover:bg-gray-300'}`}
                      onClick={() => handleRatingClick(value)}
                    >
                      {value}
                    </button>
                  ))}
                </div>
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>Poor</span>
                  <span>Excellent</span>
                </div>
              </div>
              
              <button type="submit" className="w-full btn-primary text-white py-3 rounded-lg font-medium transition">Submit Feedback</button>
            </form>
          </div>
          
          <div className="max-w-3xl mx-auto mt-16">
            <h3 className="text-2xl font-semibold mb-6 text-center">What Our Users Say</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl p-6 shadow-md card-hover">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold mr-4">RS</div>
                  <div>
                    <h4 className="font-semibold">Rahul Sharma</h4>
                    <div className="flex text-yellow-400">
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star"></i>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">"The pothole in front of my house was fixed within 2 days of reporting it on Saiyaara. This platform really works!"</p>
              </div>
              
              <div className="bg-white rounded-2xl p-6 shadow-md card-hover">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold mr-4">PM</div>
                  <div>
                    <h4 className="font-semibold">Priya Mehta</h4>
                    <div className="flex text-yellow-400">
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star"></i>
                      <i className="fas fa-star-half-alt"></i>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">"I love earning points for reporting issues. It makes me feel like I'm actually contributing to my community."</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FeedbackPage;