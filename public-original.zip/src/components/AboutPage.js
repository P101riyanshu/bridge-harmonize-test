// src/components/AboutPage.js
import React from 'react';

const AboutPage = () => {
  return (
    <div className="page">
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">About Saiyaara</h2>
          <p className="text-gray-600 text-center max-w-3xl mx-auto mb-12">Saiyaara is a civic issue reporting platform developed by a dedicated team of students passionate about improving their community through technology.</p>
          
          <div className="bg-gray-50 rounded-2xl p-8 mb-16">
            <h3 className="text-2xl font-semibold mb-6 text-center">Our Mission</h3>
            <p className="text-gray-700 text-center max-w-3xl mx-auto">To bridge the gap between citizens and local authorities by providing an efficient, transparent, and engaging platform for reporting and resolving civic issues, while encouraging community participation through gamification.</p>
          </div>
          
          <h3 className="text-2xl font-semibold mb-8 text-center">Meet Our Team</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <div className="bg-white rounded-2xl p-6 text-center shadow-md card-hover">
              <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">SK</div>
              <h4 className="text-xl font-semibold mb-2">Shubham</h4>
              <p className="text-primary font-medium mb-2">Frontend Developer</p>
              <p className="text-gray-600">Developed the user dashboard using React and Tailwind CSS, including features like complaint submission, grievance tracking, and points system.</p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 text-center shadow-md card-hover">
              <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">PJ</div>
              <h4 className="text-xl font-semibold mb-2">Priyanshi</h4>
              <p className="text-primary font-medium mb-2">Frontend Developer</p>
              <p className="text-gray-600">Built the admin dashboard for managing reports, tracking grievances, and assigning tasks, with responsive UI components.</p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 text-center shadow-md card-hover">
              <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">SS</div>
              <h4 className="text-xl font-semibold mb-2">Shreeya</h4>
              <p className="text-primary font-medium mb-2">Database Management</p>
              <p className="text-gray-600">Designs and maintains the database architecture for efficient data storage and retrieval.</p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 text-center shadow-md card-hover">
              <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">SR</div>
              <h4 className="text-xl font-semibold mb-2">Saindhav</h4>
              <p className="text-primary font-medium mb-2">Database Management</p>
              <p className="text-gray-600">Optimizes database performance and ensures data integrity and security.</p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 text-center shadow-md card-hover">
              <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">SP</div>
              <h4 className="text-xl font-semibold mb-2">Saurav</h4>
              <p className="text-primary font-medium mb-2">Backend Developer</p>
              <p className="text-gray-600">Develops server-side logic and ensures high performance and responsiveness.</p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 text-center shadow-md card-hover">
              <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">PR</div>
              <h4 className="text-xl font-semibold mb-2">Priyanshu</h4>
              <p className="text-primary font-medium mb-2">Backend Developer</p>
              <p className="text-gray-600">Implements APIs and integrates frontend components with server-side logic.</p>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-2xl p-8">
            <h3 className="text-2xl font-semibold mb-6 text-center">Our Story</h3>
            <p className="text-gray-700 mb-4">Saiyaara was born out of a college project aimed at solving real-world problems using technology. Our team noticed that many civic issues in our community went unreported or took too long to get resolved due to inefficient reporting systems.</p>
            <p className="text-gray-700 mb-4">We decided to create a platform that would make it easy for citizens to report issues, for authorities to track and manage them, and for everyone to see the progress being made in their community.</p>
            <p className="text-gray-700">The gamification aspect was added to encourage more people to participate in community improvement, turning civic duty into a rewarding experience.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;