// src/components/HomePage.js
import React from 'react';

const HomePage = () => {
  // Simple navigation function
  const navigateTo = (path) => {
    window.location.href = path;
  };

  return (
    <div className="fade-in">
      {/* Hero Section */}
      <section className="gradient-bg text-white py-16 md:py-24">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Making Our Community Better Together</h1>
            <p className="text-xl mb-8 opacity-90">Report civic issues, track their resolution, and earn points for contributing to your community's improvement.</p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <button 
                className="report-issue-btn bg-white text-primary px-8 py-4 rounded-full font-bold shadow-lg hover:shadow-xl transition"
                onClick={() => navigateTo('/dashboard')}
              >
                Report an Issue
              </button>
              <button 
                className="nav-link bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-bold hover:bg-white hover:text-primary transition"
                onClick={() => navigateTo('/about')}
              >
                Learn More
              </button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative w-80 h-80">
              <div className="absolute top-0 left-0 w-64 h-64 bg-white bg-opacity-10 rounded-full animate-float"></div>
              <div className="absolute bottom-0 right-0 w-64 h-64 bg-white bg-opacity-10 rounded-full animate-float" style={{animationDelay: '1.5s'}}></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white rounded-2xl shadow-2xl p-6 w-64 transform rotate-3">
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-primary font-bold">Issue Report</div>
                    <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Resolved</div>
                  </div>
                  <div className="text-gray-800 font-medium mb-2">Pothole on Main Street</div>
                  <div className="text-gray-600 text-sm mb-4">Reported 2 days ago</div>
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold">SP</div>
                    <div className="ml-2 text-xs text-gray-600">+15 points earned</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">How It Works</h2>
          <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">Saiyaara makes it easy to report civic issues and track their resolution progress in just a few simple steps.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-2xl p-6 text-center card-hover">
              <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">1</div>
              <h3 className="text-xl font-semibold mb-2">Report an Issue</h3>
              <p className="text-gray-600">Submit details with photos, location, and description of the civic issue you've encountered.</p>
            </div>
            
            <div className="bg-gray-50 rounded-2xl p-6 text-center card-hover">
              <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">2</div>
              <h3 className="text-xl font-semibold mb-2">Track Progress</h3>
              <p className="text-gray-600">Monitor the status of your report through various stages until it gets resolved.</p>
            </div>
            
            <div className="bg-gray-50 rounded-2xl p-6 text-center card-hover">
              <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto mb-4">3</div>
              <h3 className="text-xl font-semibold mb-2">Earn Points</h3>
              <p className="text-gray-600">Get rewarded with points for your civic engagement that you can showcase in your community.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Issues Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Recently Resolved Issues</h2>
          <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">See how Saiyaara is helping improve our community every day.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl overflow-hidden shadow-md card-hover">
              <div className="h-40 bg-gray-200 relative">
                <div className="absolute bottom-2 right-2 status-badge status-resolved">Resolved</div>
              </div>
              <div className="p-5">
                <h3 className="font-semibold text-lg mb-2">Pothole Repair</h3>
                <p className="text-gray-600 text-sm mb-4">Main Street, Downtown Area</p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Fixed within 48 hours</span>
                  <span className="text-primary font-bold">+20 points</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl overflow-hidden shadow-md card-hover">
              <div className="h-40 bg-gray-200 relative">
                <div className="absolute bottom-2 right-2 status-badge status-resolved">Resolved</div>
              </div>
              <div className="p-5">
                <h3 className="font-semibold text-lg mb-2">Garbage Collection</h3>
                <p className="text-gray-600 text-sm mb-4">Central Park Area</p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Fixed within 24 hours</span>
                  <span className="text-primary font-bold">+15 points</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl overflow-hidden shadow-md card-hover">
              <div className="h-40 bg-gray-200 relative">
                <div className="absolute bottom-2 right-2 status-badge status-resolved">Resolved</div>
              </div>
              <div className="p-5">
                <h3 className="font-semibold text-lg mb-2">Street Light Repair</h3>
                <p className="text-gray-600 text-sm mb-4">Residential Sector 15</p>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Fixed within 72 hours</span>
                  <span className="text-primary font-bold">+25 points</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-10">
            <button 
              className="nav-link btn-primary text-white px-6 py-3 rounded-full font-medium"
              onClick={() => navigateTo('/dashboard')}
            >
              View All Issues
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;