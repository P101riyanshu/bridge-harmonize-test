// src/components/Header.js
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const isActive = (path) => {
    return location.pathname === path ? 'text-primary' : 'text-gray-700';
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link to="/" className="text-2xl font-bold text-primary cursor-pointer">
            Saiyaara
          </Link>
        </div>
        
        <div className="hidden md:flex space-x-8">
          <Link 
            to="/" 
            className={`nav-link hover:text-primary transition ${isActive('/')}`}
          >
            Home
          </Link>
          <Link 
            to="/about" 
            className={`nav-link hover:text-primary transition ${isActive('/about')}`}
          >
            About Us
          </Link>
          <Link 
            to="/feedback" 
            className={`nav-link hover:text-primary transition ${isActive('/feedback')}`}
          >
            Feedback
          </Link>
          <Link 
            to="/dashboard" 
            className={`nav-link hover:text-primary transition ${isActive('/dashboard')}`}
          >
            Dashboard
          </Link>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="hidden md:flex items-center bg-blue-50 px-3 py-1 rounded-full">
            <i className="fas fa-phone-alt text-primary text-sm mr-2"></i>
            <span className="text-sm font-medium">Helpline: 1800-123-4567</span>
          </div>
          
          <div className="relative">
            <select className="bg-gray-100 border-0 py-2 px-4 pr-8 rounded-full text-sm focus:ring-2 focus:ring-primary focus:outline-none appearance-none">
              <option>English</option>
              <option>Hindi</option>
            </select>
            <i className="fas fa-chevron-down text-gray-500 absolute right-3 top-3 text-xs pointer-events-none"></i>
          </div>
          
          <div className="flex space-x-2">
            <button className="admin-login bg-gray-100 hover:bg-gray-200 text-gray-800 px-4 py-2 rounded-full text-sm font-medium transition">
              Admin Login
            </button>
            <Link 
              to="/login"
              className="user-login btn-primary text-white px-4 py-2 rounded-full text-sm font-medium"
            >
              User Login
            </Link>
          </div>
          
          <button 
            className="md:hidden text-gray-700" 
            onClick={toggleMobileMenu}
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`mobile-menu md:hidden bg-white border-t border-gray-200 px-4 ${isMobileMenuOpen ? 'open' : ''}`}>
        <div className="flex flex-col space-y-4 py-4">
          <Link 
            to="/" 
            className={`nav-link hover:text-primary transition ${isActive('/')}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Home
          </Link>
          <Link 
            to="/about" 
            className={`nav-link hover:text-primary transition ${isActive('/about')}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            About Us
          </Link>
          <Link 
            to="/feedback" 
            className={`nav-link hover:text-primary transition ${isActive('/feedback')}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Feedback
          </Link>
          <Link 
            to="/dashboard" 
            className={`nav-link hover:text-primary transition ${isActive('/dashboard')}`}
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Dashboard
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;