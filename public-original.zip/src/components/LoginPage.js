// src/components/LoginPage.js
import React, { useState } from 'react';

const LoginPage = () => {
  const [activeTab, setActiveTab] = useState('login-tab');
  const [agreeToTerms, setAgreeToTerms] = useState(false);

  const handleLogin = (e) => {
    e.preventDefault();
    // Perform login logic
    // Then redirect to dashboard
    window.location.href = '/dashboard';
  };

  const handleRegister = (e) => {
    e.preventDefault();
    if (!agreeToTerms) {
      alert('Please agree to the Terms of Service and Privacy Policy');
      return;
    }
    // Perform registration logic
    alert('Registration successful! Please check your email to verify your account.');
    setActiveTab('login-tab');
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="page">
      <section className="py-16 bg-gray-50 min-h-screen flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="gradient-bg py-6 px-6 text-white text-center">
              <h2 className="text-2xl font-bold">Welcome to Saiyaara</h2>
              <p className="opacity-90">Sign in to your account or create a new one</p>
            </div>
            
            <div className="p-6">
              <div className="flex border-b border-gray-200 mb-6">
                <button 
                  className={`py-2 px-4 font-medium ${activeTab === 'login-tab' ? 'text-primary border-b-2 border-primary' : 'text-gray-500'}`}
                  onClick={() => handleTabChange('login-tab')}
                >
                  Login
                </button>
                <button 
                  className={`py-2 px-4 font-medium ${activeTab === 'register-tab' ? 'text-primary border-b-2 border-primary' : 'text-gray-500'}`}
                  onClick={() => handleTabChange('register-tab')}
                >
                  Register
                </button>
              </div>
              
              {/* Login Form */}
              {activeTab === 'login-tab' && (
                <div id="login-tab">
                  <form onSubmit={handleLogin}>
                    <div className="mb-4">
                      <label className="block text-gray-700 mb-2" htmlFor="login-email">Email Address</label>
                      <input 
                        type="email" 
                        id="login-email" 
                        className="w-full bg-gray-100 rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" 
                        placeholder="Enter your email" 
                        required 
                      />
                    </div>
                    
                    <div className="mb-6">
                      <label className="block text-gray-700 mb-2" htmlFor="login-password">Password</label>
                      <input 
                        type="password" 
                        id="login-password" 
                        className="w-full bg-gray-100 rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" 
                        placeholder="Enter your password" 
                        required 
                      />
                      <div className="text-right mt-2">
                        <a href="#" className="text-sm text-primary hover:underline">Forgot Password?</a>
                      </div>
                    </div>
                    
                    <button type="submit" className="w-full btn-primary text-white py-3 rounded-lg font-medium transition">Sign In</button>
                  </form>
                  
                  <div className="text-center mt-6">
                    <p className="text-gray-600">Or sign in with</p>
                    <div className="flex justify-center space-x-4 mt-2">
                      <button className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition">
                        <i className="fab fa-google text-red-500"></i>
                      </button>
                      <button className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition">
                        <i className="fab fa-facebook-f text-blue-600"></i>
                      </button>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Register Form */}
              {activeTab === 'register-tab' && (
                <div id="register-tab">
                  <form onSubmit={handleRegister}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-gray-700 mb-2" htmlFor="first-name">First Name</label>
                        <input 
                          type="text" 
                          id="first-name" 
                          className="w-full bg-gray-100 rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" 
                          placeholder="First name" 
                          required 
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 mb-2" htmlFor="last-name">Last Name</label>
                        <input 
                          type="text" 
                          id="last-name" 
                          className="w-full bg-gray-100 rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" 
                          placeholder="Last name" 
                          required 
                        />
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-gray-700 mb-2" htmlFor="register-email">Email Address</label>
                      <input 
                        type="email" 
                        id="register-email" 
                        className="w-full bg-gray-100 rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" 
                        placeholder="Enter your email" 
                        required 
                      />
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-gray-700 mb-2" htmlFor="register-password">Password</label>
                      <input 
                        type="password" 
                        id="register-password" 
                        className="w-full bg-gray-100 rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" 
                        placeholder="Create a password" 
                        required 
                        minLength="6"
                      />
                    </div>
                    
                    <div className="mb-6">
                      <label className="block text-gray-700 mb-2" htmlFor="confirm-password">Confirm Password</label>
                      <input 
                        type="password" 
                        id="confirm-password" 
                        className="w-full bg-gray-100 rounded-lg border border-gray-300 px-4 py-3 focus:ring-2 focus:ring-primary focus:border-transparent focus:outline-none" 
                        placeholder="Confirm your password" 
                        required 
                      />
                    </div>
                    
                    <div className="mb-6">
                      <div className="flex items-center">
                        <input 
                          type="checkbox" 
                          id="terms" 
                          className="w-4 h-4 text-primary focus:ring-primary border-gray-300 rounded"
                          checked={agreeToTerms}
                          onChange={(e) => setAgreeToTerms(e.target.checked)}
                        />
                        <label htmlFor="terms" className="ml-2 text-sm text-gray-600">
                          I agree to the <a href="#" className="text-primary hover:underline">Terms of Service</a> and <a href="#" className="text-primary hover:underline">Privacy Policy</a>
                        </label>
                      </div>
                    </div>
                    
                    <button type="submit" className="w-full btn-primary text-white py-3 rounded-lg font-medium transition">Create Account</button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LoginPage;