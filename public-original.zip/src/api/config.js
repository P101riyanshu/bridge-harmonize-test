// API configuration for the Saiyaara React app
const API_BASE_URL = 'http://localhost:3001/api';

// API endpoints
const ENDPOINTS = {
  // Auth endpoints
  REGISTER: '/auth/register',
  LOGIN: '/auth/login',
  LOGOUT: '/auth/logout',
  
  // Report endpoints
  REPORTS: '/reports',
  REPORT_DETAILS: (id) => `/reports/${id}`,
  CREATE_REPORT: '/reports',
  UPDATE_REPORT: (id) => `/reports/${id}`,
  
  // Map endpoints
  MAP_DATA: '/map/data',
  MAP_FILTERS: '/map/filters',
  
  // User profile
  USER_PROFILE: '/auth/profile',
  UPDATE_PROFILE: '/auth/profile',
};

// Request helper with authentication
const apiRequest = async (endpoint, options = {}) => {
  const token = localStorage.getItem('user_token');
  
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }
  
  const config = {
    ...options,
    headers,
  };
  
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'API request failed');
    }
    
    return data;
  } catch (error) {
    console.error('API request error:', error);
    throw error;
  }
};

export { API_BASE_URL, ENDPOINTS, apiRequest };